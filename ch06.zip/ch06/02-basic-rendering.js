// basic usage
app.get('/about', (req, res) => {
    res.render('about')
   })
   